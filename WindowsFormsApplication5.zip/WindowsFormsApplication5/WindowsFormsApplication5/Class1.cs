﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WindowsFormsApplication5
{
    class Class1
    {
        static string username;
        public static string uname
        {
            get
            {
                return username;
            }
            set
            {
                username = value;
            }
        }

    }
}
