﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.SignalR;
using SocketImpleme.Hubs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SocketImpleme.Controllers
{
    public class SocketController : Controller
    {
    //    private IHubContext<SocketHub> _hub;
    //    public SocketController(IHubContext<SocketHub> hubContext)
    //    {
    //        this._hub = hubContext;
    //    }
    //    public async Task<IActionResult> Index()
    //    {
    //        await this._hub.Clients.All.SendAsync("device_imei", "attributed");
    //        return Ok("hello");
    //    }
    }
}
