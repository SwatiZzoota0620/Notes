﻿using Microsoft.AspNetCore.SignalR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SocketImpleme.Hubs
{
    public class SocketHub:Hub
    {
        public void sendMessage(string imei,string message)
        {
            Clients.All.SendAsync("device_"+imei,message);
        }
    }
}
