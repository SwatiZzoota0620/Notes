﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

namespace Hospital_Management_System
{
    public partial class doctors : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            string iid;
            string qy = "select id from doctor_applications order by id Desc";
            SqlConnection con = new SqlConnection("Data Source=.\\sqlexpress;Initial Catalog=Hospital_management_system;Integrated Security=True");
            con.Open();
            SqlCommand cmdd = new SqlCommand(qy, con);
            SqlDataReader dr = cmdd.ExecuteReader();
            if (dr.Read())
            {
                int id = int.Parse(dr[0].ToString()) + 1;
                iid = id.ToString("00000");
            }
            else if (Convert.IsDBNull(dr))
            {
                iid = ("00001");
            }
            else
            {
                iid = ("00001");
            }
            String idd = iid.ToString();
            con.Close();
            String status = "pending";
           String  apply_date = DateTime.Now.ToString("MM/dd/yyyy");
           
           
if (FileUpload1.HasFile)  
        {  
            string str = FileUpload1.FileName;  
            FileUpload1.PostedFile.SaveAs(Server.MapPath("~/cv/" + str));  
            string file = "~/cv/" + str.ToString();         
          con.Open();
  
             SqlCommand cmd = new SqlCommand("insert into doctor_applications(id,name,email,resume,Apply_date,status) values('" + idd + "','" + TextBox1.Text + "','" + TextBox2.Text + "','" + file + "','" + apply_date + "','" + status + "')", con);
           int query=cmd.ExecuteNonQuery();
  
           if (query > 0)
           {
              Label1.Visible=true;
              Label1.Text="successfully applied";

           }
}
           else
           {   Label1.Visible=true;
               Label1.Text="Try Again!!!!";
               TextBox1.Text = "";
               TextBox2.Text = "";
              

           }

            con.Close();
            
        }
        }
    }

