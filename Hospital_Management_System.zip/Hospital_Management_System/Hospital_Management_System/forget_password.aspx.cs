﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

namespace Hospital_Management_System
{
    public partial class forget_password : System.Web.UI.Page
    {
        
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
                Label1.Text = Request.QueryString[0];
                SqlConnection con = new SqlConnection("Data Source=.\\sqlexpress;Initial Catalog=Hospital_management_system;Integrated Security=True");
                con.Open();
                SqlCommand cmd = new SqlCommand("update patient set password ='" + TextBox1.Text + "'  where email='" +Label1.Text+ "'", con);
                int query=cmd.ExecuteNonQuery();
                if (query > 0)
                {
                    

                    Response.Redirect("signin_patient.aspx?msg='SUCCESSFULLY UPDATED PASSWORD'");
                }
                else
                {

                    Response.Redirect("signin_patient.aspx?msg='PASSWORD NOT UPDATED'");
                }
               con.Close();

        }
    }
}