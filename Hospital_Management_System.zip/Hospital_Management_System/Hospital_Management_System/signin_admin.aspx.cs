﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data.SqlClient;


namespace Hospital_Management_System
{
    public partial class signin_admin : System.Web.UI.Page
    {


        protected void Button1_Click(object sender, EventArgs e)
        {
            if (TextBox1.Text != "" && TextBox2.Text != "")
            {


                SqlConnection con = new SqlConnection("Data Source=.\\sqlexpress;Initial Catalog=Hospital_management_system;Integrated Security=True");
                con.Open();
                SqlCommand cmd = new SqlCommand("select * from admin where username='" + TextBox1.Text + "' and password='" + TextBox2.Text + "'", con);
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {

                    Response.Redirect("admin_dashboard.aspx");

                }
                else
                {
                   
                    Label1.Visible = true;

                    Label1.Text = ("Incorrect Username and password");

                }



            }
            else
            {

                if (TextBox1.Text == "" && TextBox2.Text != "")
                {
                    Label1.Visible = true;
                    Label1.Text = ("Enter username!!!");
                }
                else if (TextBox2.Text == "" && TextBox1.Text != "")
                {
                    Label1.Visible = true;
                    Label1.Text = ("Enter Password!!!");
                }
                else if (TextBox1.Text == "" && TextBox2.Text == "")
                {
                    Label1.Visible = true;
                    Label1.Text = ("Enter username and Password!!!");
                }


            }
        }

       

        protected void Button2_Click1(object sender, EventArgs e)
        {
            Response.Redirect("home.aspx");

        }
    }
}