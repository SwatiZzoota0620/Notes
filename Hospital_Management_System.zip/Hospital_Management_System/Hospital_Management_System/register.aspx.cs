﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

namespace Hospital_Management_System
{
    public partial class register : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            string iid;
            string qy = "select id from registeration order by id Desc";
            SqlConnection con = new SqlConnection("Data Source=.\\sqlexpress;Initial Catalog=Hospital_management_system;Integrated Security=True");
            con.Open();
            SqlCommand cmdd = new SqlCommand(qy, con);
            SqlDataReader dr = cmdd.ExecuteReader();
            if (dr.Read())
            {
                int id = int.Parse(dr[0].ToString()) + 1;
                iid = id.ToString("00000");
            }
            else if (Convert.IsDBNull(dr))
            {
                iid = ("00001");
            }
            else
            {
                iid = ("00001");
            }
            String idd = iid.ToString();
            con.Close();
            String c  = Convert.ToString(Calendar1.SelectedDate.ToShortDateString());
            string gender = string.Empty;
            if (RadioButton1.Checked)
            {
                gender = "Male";
            }
            else if (RadioButton2.Checked)
            {
                gender = "Female";
            }

            String status = "inactive";
           String  registeration_date = DateTime.Now.ToString("MM/dd/yyyy");
           con.Open();
            SqlCommand cmd = new SqlCommand("insert into registeration(id,first_name,last_name,dob,gender,email,phone_number,password,address,status,date_of_registeration) values('" + idd + "','" + TextBox1.Text + "','" + TextBox2.Text + "','" + c + "','" + gender + "','" + TextBox3.Text + "','" + TextBox4.Text + "','" + TextBox5.Text + "','" + TextBox7.Text + "','" + status + "', '" + registeration_date + "')", con);
           int query=cmd.ExecuteNonQuery();
           if (query > 0)
           {
               Response.Redirect("signin_patient.aspx");

           }
           else
           {
               TextBox1.Text = "";
               TextBox2.Text = "";
               TextBox3.Text = "";
               TextBox4.Text = "";
               TextBox5.Text = "";
               TextBox6.Text = "";
               TextBox7.Text = "";

           }

            con.Close();
            
        }
    }
}