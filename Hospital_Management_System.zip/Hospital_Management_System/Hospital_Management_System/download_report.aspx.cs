﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;

namespace Hospital_Management_System
{
    public partial class download_report : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
           
            string filePath = Request.QueryString[0];
            Response.ContentType = ContentType;
            Response.AppendHeader("Content-Disposition", "attachment; filename=" + Path.GetFileName(filePath));
            Response.WriteFile(filePath);
            Response.End();

        }
    }
}