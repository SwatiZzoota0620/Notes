﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Text;

namespace Hospital_Management_System
{
    public partial class noticeboard : System.Web.UI.Page
    {
        StringBuilder table=new StringBuilder();
        protected void Page_Load(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=.\\sqlexpress;Initial Catalog=Hospital_management_system;Integrated Security=True");
            con.Open();
            SqlCommand cmd = new SqlCommand("select * from noticeboard ORDER BY id DESC ", con);
            SqlDataReader dr = cmd.ExecuteReader();
            table.Append("<center><table style='width:1000px; heigth:auto;' class='table'>");
           
             table.Append("<tr>");
             table.Append("<th bgcolor='#5DADE2'>S.NO</th>");
             table.Append("<th bgcolor='#5DADE2'>TITLE</th>");
            table.Append("<th bgcolor='#5DADE2'>NOTICE</th>");
            table.Append("<th bgcolor='#5DADE2'>DATE</th>");
            
            table.Append("</tr>");
            if(dr.HasRows)
            {
                while(dr.Read())
                {
                     table.Append("<tr>");
             table.Append("<td>"+dr[0]+"</td>");
             table.Append("<td>"+dr[1]+"</td>");
             table.Append("<td>"+dr[2]+"</td>");
             table.Append("<td>" + dr[3] + "</td>");

             table.Append("</tr>");
                }
            }
            table.Append("</center></table>");
            PlaceHolder1.Controls.Add(new Literal {Text=table.ToString()});

          


        }
    }
}