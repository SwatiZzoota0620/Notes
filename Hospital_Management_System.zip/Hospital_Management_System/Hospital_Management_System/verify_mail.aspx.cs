﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Net;
using System.Net.Mail;
using System.Data.SqlClient;
namespace Hospital_Management_System
{
    public partial class verify_mail : System.Web.UI.Page
    {
        public static String randomCode;
        public static String to;
        
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=.\\sqlexpress;Initial Catalog=Hospital_management_system;Integrated Security=True");
            con.Open();
            SqlCommand cmd = new SqlCommand("select * from patient where email='" + TextBox1.Text + "'", con);
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                String from, pass, messageBody;
                Random rand = new Random();
                randomCode = (rand.Next(999999)).ToString();
                MailMessage message = new MailMessage();
                to = (TextBox1.Text).ToString();
                from = "thakurangel12345@gmail.com";
                pass = "AngelThakur!9";
                messageBody = "your reset code is " + randomCode;
                message.To.Add(to);
                message.From = new MailAddress(from);
                message.Body = messageBody;
                message.Subject = "password reseting code";
                SmtpClient smtp = new SmtpClient("smtp.gmail.com");
                smtp.EnableSsl = true;
                smtp.Port = 587;
                smtp.DeliveryMethod = SmtpDeliveryMethod.Network;
                smtp.Credentials = new NetworkCredential(from, pass);

                try
                {
                    smtp.Send(message);

                }
                catch (Exception ex)
                {
                    Label1.Visible = true;
                    Label1.Text = ex.Message;
                }







            }
            else
            {
                Label1.Visible = true;
                Label1.Text ="Email doesn't exist!!!";
            }
           
           
            
        }


        protected void Button2_Click(object sender, EventArgs e)
        {
            
         
            
            if ( randomCode==(TextBox2.Text).ToString())
            {
                to = TextBox1.Text;
                Response.Redirect("forget_password.aspx?Email=" + TextBox1.Text + "");
                

            }
            else
            {
                Label1.Visible = true;
                Label1.Text = "Wrong Code" ;
                TextBox2.Text = "";
            }
        }
    }
}