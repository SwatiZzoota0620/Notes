﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

namespace Hospital_Management_System
{
    public partial class signin_patient : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            if (TextBox1.Text != "" && TextBox2.Text != "")
            {


                SqlConnection con = new SqlConnection("Data Source=.\\sqlexpress;Initial Catalog=Hospital_management_system;Integrated Security=True");
                con.Open();
                SqlCommand cmd = new SqlCommand("select * from registeration where email='" + TextBox1.Text + "' and password='" + TextBox2.Text + "' and status ='active' ", con);
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {

                    Response.Redirect("patient_dashboard.aspx");

                }
                else
                {

                    Label1.Visible = true;

                    Label1.Text = ("Incorrect Username and password");

                }



            }
            else
            {

                if (TextBox1.Text == "" && TextBox2.Text != "")
                {
                    Label1.Visible = true;
                    Label1.Text = ("Enter username!!!");
                }
                else if (TextBox2.Text == "" && TextBox1.Text != "")
                {
                    Label1.Visible = true;
                    Label1.Text = ("Enter Password!!!");
                }
                else if (TextBox1.Text == "" && TextBox2.Text == "")
                {
                    Label1.Visible = true;
                    Label1.Text = ("Enter username and Password!!!");
                }


            }

        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Response.Redirect("home.aspx");
        }
    }
}