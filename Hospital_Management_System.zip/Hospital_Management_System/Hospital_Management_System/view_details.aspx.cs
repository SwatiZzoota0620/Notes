﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Text;
using System.Data; 

namespace Hospital_Management_System
{
    public partial class view_details : System.Web.UI.Page
    {
        StringBuilder table = new StringBuilder();
        StringBuilder table1 = new StringBuilder();
        StringBuilder table2 = new StringBuilder();

        protected void Page_Load(object sender, EventArgs e)
        {
            
           

            SqlConnection con = new SqlConnection("Data Source=.\\sqlexpress;Initial Catalog=Hospital_management_system;Integrated Security=True");
            con.Open();
            SqlCommand cd = new SqlCommand("select * from patient where patient_id='" + Request.QueryString[0] + "' ", con);
            SqlDataReader dr = cd.ExecuteReader();
            if (dr.HasRows)
            {
                dr.Read();
                Label1.Text = Convert.ToString(dr["name"]);
                TextBox1.Text = Convert.ToString(dr["patient_id"]);
                TextBox2.Text = Convert.ToString(dr["name"]);
                TextBox3.Text = Convert.ToString(dr["age"]);
                TextBox4.Text = Convert.ToString(dr["blood_group"]);
                TextBox5.Text = Convert.ToString(dr["mobile"]);
                TextBox6.Text = Convert.ToString(dr["email"]);
                TextBox7.Text = Convert.ToString(dr["password"]);

            }


            table.AppendFormat("<ul class='treeview-menu'>");

            table.AppendFormat("<li><a href='view_details.aspx?patient_id=" + Request.QueryString[0] + "'>View Details</a></li>");

            table.AppendFormat("</ul>");
            PlaceHolder1.Controls.Add(new Literal { Text = table.ToString() });


            table1.AppendFormat("<ul class='treeview-menu'>");

            table1.AppendFormat("<li><a href='view_reports.aspx?patient_id=" + Request.QueryString[0] + "'>View Reports</a></li>");

            table1.AppendFormat("</ul>");
            PlaceHolder2.Controls.Add(new Literal { Text = table1.ToString() });





            table2.AppendFormat("<a href='patient_dashboard.aspx?patient_id=" + Request.QueryString[0] + "' class='logo'>");

            table2.AppendFormat("<h3 style='color:white;'>Patient Panel</h3>");

            table2.AppendFormat(" </a>");
            PlaceHolder3.Controls.Add(new Literal { Text = table2.ToString() });
        }
    }
}