﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

namespace Hospital_Management_System
{
    public partial class home : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            string iid;
            string qy = "select appointment_id from online_appointment order by appointment_id Desc";
            SqlConnection con = new SqlConnection("Data Source=.\\sqlexpress;Initial Catalog=Hospital_management_system;Integrated Security=True");
            con.Open();
            SqlCommand cmdd = new SqlCommand(qy, con);
            SqlDataReader dr = cmdd.ExecuteReader();
            if (dr.Read())
            {
                int id = int.Parse(dr[0].ToString()) + 1;
                iid = id.ToString("00000");
            }
            else if (Convert.IsDBNull(dr))
            {
                iid = ("00001");
            }
            else
            {
                iid = ("00001");
            }
            String idd = iid.ToString();
            con.Close();
            String appointment_date = DateTime.Now.ToString("MM/dd/yyyy");


            con.Open();

            SqlCommand cmd = new SqlCommand("insert into online_appointment(appointment_id,full_name,email,appointment_date,mobile,problem) values('" + idd + "','" + TextBox1.Text + "','" + TextBox2.Text + "','" + appointment_date + "','" + TextBox3.Text + "','" + TextBox4.Text + "')", con);
                int query = cmd.ExecuteNonQuery();

                if (query > 0)
                {
                    Label1.Visible = true;
                    Label1.Text = "successfully applied";
                    TextBox1.Text = "";
                    TextBox2.Text = "";
                    TextBox3.Text = "";
                    TextBox4.Text = "";

                }
           

            con.Close();
        }
    }
}